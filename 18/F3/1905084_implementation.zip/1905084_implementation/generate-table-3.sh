#!/bin/bash
for i in {36..45}; do
    ./max_cut "set1/g$i.rud" 50
done