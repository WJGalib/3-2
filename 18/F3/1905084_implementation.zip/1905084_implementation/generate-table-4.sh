#!/bin/bash
for i in {46..54}; do
    ./max_cut "set1/g$i.rud" 50
done