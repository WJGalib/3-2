#!/bin/bash
for i in {25..35}; do
    ./max_cut "set1/g$i.rud" 50
done