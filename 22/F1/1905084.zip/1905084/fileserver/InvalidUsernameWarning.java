package fileserver;

import java.io.Serializable;


public class InvalidUsernameWarning implements Serializable {
    
}
